#include "mbed.h"

DigitalOut Vcc0(A2);
AnalogIn aInnA1(A1);
DigitalOut Gnd0(A0);

DigitalOut Vcc1(A5);
AnalogIn aInnA4(A4);
DigitalOut Gnd1(A3);

int main() {
    Vcc0=1; Gnd0=0;
    Vcc1=1; Gnd1=0;
          
    while(1)
     {          
        printf("$VOLTAGE,A1," );
        printf("%.2f",aInnA1.read()*3.3f);
        printf(",A4,");
        printf("%.2f",aInnA4.read()*3.3f);
        printf("\r\n");
        
        wait_ms(300);
    }
}




